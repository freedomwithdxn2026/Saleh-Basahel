@php
    $active = $active ?? '';
    $navItems = [
        ['key' => 'dashboard', 'label' => 'Dashboard', 'route' => route('admin.dashboard')],
        ['key' => 'leads', 'label' => 'Leads', 'route' => route('admin.leads.index')],
        ['key' => 'content', 'label' => 'Content Management', 'route' => route('admin.content.edit')],
        ['key' => 'profile', 'label' => 'Profile Section', 'route' => route('admin.profile.edit')],
    ];
@endphp
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'Admin Panel' }} | Saleh Basahel</title>
    <link rel="icon" type="image/png" href="{{ asset('favcon.png') }}">
    <link rel="apple-touch-icon" href="{{ asset('favcon.png') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: Montserrat, Arial, sans-serif; background: #f4f8f5; color: #111; }
        a { color: inherit; text-decoration: none; }
        .shell { min-height: 100vh; display: grid; grid-template-columns: 280px minmax(0, 1fr); }
        .sidebar { background: #07180f; color: #fff; padding: 28px 22px; position: sticky; top: 0; height: 100vh; }
        .brand { display: flex; align-items: center; gap: 12px; margin-bottom: 34px; }
        .mark { width: 50px; height: 50px; border-radius: 999px; display: grid; place-items: center; background: linear-gradient(135deg, #1E9447, #16763A); box-shadow: 0 14px 28px rgba(30,148,71,.25); }
        .mark svg { width: 31px; height: 31px; }
        .brand strong { display: block; font-size: 20px; line-height: 1; }
        .brand span { color: #58c47a; font-size: 12px; font-weight: 700; letter-spacing: 3px; }
        .nav { display: grid; gap: 8px; }
        .nav a { border-radius: 14px; padding: 14px 16px; color: rgba(255,255,255,.72); font-weight: 700; transition: .2s ease; }
        .nav a:hover, .nav a.active { background: rgba(30,148,71,.18); color: #fff; }
        .logout { margin-top: 30px; }
        .logout button { width: 100%; border: 1px solid rgba(255,255,255,.15); background: rgba(255,255,255,.06); color: #fff; border-radius: 14px; padding: 12px; font-weight: 700; cursor: pointer; }
        .main { min-width: 0; padding: 34px; }
        .topbar { display: flex; justify-content: space-between; align-items: center; gap: 18px; margin-bottom: 28px; }
        .topbar h1 { margin: 0; font-size: clamp(24px, 2.4vw, 34px); font-weight: 600; line-height: 1.2; }
        .main h2 { font-size: clamp(20px, 1.8vw, 28px); font-weight: 600; line-height: 1.25; }
        .visit { background: #1E9447; color: #fff; padding: 13px 18px; border-radius: 999px; font-weight: 800; box-shadow: 0 12px 24px rgba(30,148,71,.18); }
        .card { background: #fff; border: 1px solid #e3ebe5; border-radius: 22px; box-shadow: 0 18px 44px rgba(7,24,15,.07); }
        .pad { padding: 24px; }
        .grid { display: grid; gap: 18px; }
        .stats { grid-template-columns: repeat(4, minmax(0, 1fr)); margin-bottom: 22px; }
        .stat strong { display: block; font-size: 34px; }
        .stat span { color: #66736b; font-weight: 600; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 14px 12px; border-bottom: 1px solid #edf1ee; text-align: left; vertical-align: top; }
        th { color: #66736b; font-size: 12px; text-transform: uppercase; letter-spacing: .08em; }
        .field { display: grid; gap: 8px; margin-bottom: 18px; }
        label { font-weight: 800; }
        input, textarea, select { width: 100%; border: 1px solid #dbe5df; border-radius: 14px; padding: 13px 14px; font: inherit; background: #fff; }
        textarea { min-height: 110px; resize: vertical; }
        .btn { border: 0; background: #1E9447; color: #fff; padding: 13px 18px; border-radius: 999px; font-weight: 800; cursor: pointer; }
        .muted { color: #66736b; }
        .notice { padding: 13px 16px; border-radius: 14px; background: #eaf8ef; color: #16763A; font-weight: 700; margin-bottom: 18px; }
        .tabs { display: flex; gap: 8px; margin-bottom: 18px; }
        .tabs a { padding: 10px 14px; border-radius: 999px; border: 1px solid #dbe5df; font-weight: 800; }
        .tabs a.active { background: #1E9447; color: #fff; border-color: #1E9447; }
        .image-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .preview { width: 100%; aspect-ratio: 16 / 10; object-fit: cover; border-radius: 16px; border: 1px solid #e2e8e4; background: #f7faf8; }
        .searchbar { display: flex; gap: 12px; margin-bottom: 18px; }
        .searchbar input { max-width: 420px; }
        .block { display: block; }
        .small { font-size: 12px; margin-top: 5px; }
        .eyebrow { margin: 0 0 7px; color: #16763A; font-size: 12px; font-weight: 800; letter-spacing: .14em; text-transform: uppercase; }
        .lead-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 20px; margin-bottom: 22px; }
        .lead-header h2 { margin: 0 0 8px; font-size: clamp(21px, 1.8vw, 28px); font-weight: 600; line-height: 1.25; }
        .lead-header p:last-child { margin: 0; max-width: 760px; line-height: 1.7; }
        .live-pill { display: inline-flex; align-items: center; gap: 8px; border: 1px solid #cfeadd; background: #eaf8ef; color: #16763A; border-radius: 999px; padding: 9px 13px; font-size: 12px; font-weight: 800; white-space: nowrap; }
        .live-pill span { width: 8px; height: 8px; border-radius: 50%; background: #1E9447; box-shadow: 0 0 0 5px rgba(30,148,71,.12); }
        .filters { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 18px; align-items: center; }
        .filters input { flex: 1 1 280px; }
        .filters select { flex: 1 1 145px; }
        .btn-light { background: #eef5f0; color: #111; }
        .btn-danger { background: #b42318; color: #fff; }
        .btn-small { padding: 8px 12px; font-size: 12px; white-space: nowrap; }
        .action-buttons { display: flex; align-items: center; gap: 8px; min-width: max-content; }
        .action-buttons form { margin: 0; }
        .text-link { color: #16763A; font-weight: 800; }
        .pipeline-tabs { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 10px; margin-bottom: 16px; }
        .pipeline-tabs a { display: inline-flex; align-items: center; gap: 8px; border: 1px solid #dbe5df; border-radius: 999px; padding: 9px 12px; font-size: 12px; font-weight: 800; white-space: nowrap; }
        .pipeline-tabs a.active { background: #1E9447; border-color: #1E9447; color: #fff; }
        .pipeline-tabs strong { display: grid; place-items: center; min-width: 22px; height: 22px; border-radius: 50%; background: rgba(255,255,255,.22); }
        .lead-table th a { color: inherit; }
        .lead-manager { min-width: 0; max-width: 100%; overflow: hidden; }
        .table-wrap { width: 100%; max-width: 100%; overflow-x: auto; overscroll-behavior-inline: contain; scrollbar-gutter: stable; }
        .lead-table { min-width: 1380px; table-layout: auto; }
        .lead-table td { max-width: 280px; overflow-wrap: anywhere; word-break: break-word; font-size: 14px; line-height: 1.55; }
        .lead-table th:last-child, .lead-table td:last-child { position: sticky; right: 0; z-index: 1; background: #fff; box-shadow: -12px 0 20px rgba(7,24,15,.06); }
        .lead-table th:last-child { z-index: 2; }
        .source-badge, .status-badge { display: inline-flex; align-items: center; border-radius: 999px; padding: 7px 10px; font-size: 12px; font-weight: 800; white-space: nowrap; }
        .source-badge { background: #edf7f1; color: #16763A; }
        .source-whatsapp { background: #e8fff0; color: #0b7a35; }
        .source-landing-page, .source-website { background: #fff7dd; color: #755300; }
        .status-badge { background: #f1f5f3; color: #34423a; }
        .temperature-badge { display: inline-flex; border-radius: 999px; padding: 7px 10px; font-size: 12px; font-weight: 800; }
        .temperature-hot { background: #ffe8e8; color: #a41f1f; }
        .temperature-warm { background: #fff4d6; color: #745100; }
        .temperature-cold { background: #eaf3ff; color: #245b91; }
        .conversation-cell { min-width: 260px; max-width: 360px; }
        .conversation-cell details { border: 1px solid #e1e9e4; border-radius: 14px; background: #fbfdfb; padding: 10px 12px; }
        .conversation-cell summary { cursor: pointer; color: #16763A; font-weight: 800; }
        .conversation-cell pre { margin: 10px 0 0; white-space: pre-wrap; word-break: break-word; font: 12px/1.6 ui-monospace, SFMono-Regular, Consolas, monospace; color: #34423a; }
        .pagination-wrap { margin-top: 18px; }
        .lead-detail-head { display: flex; align-items: center; justify-content: space-between; gap: 16px; margin-bottom: 18px; }
        .detail-grid { display: grid; grid-template-columns: minmax(0, 1.45fr) minmax(300px, .7fr); gap: 20px; align-items: start; }
        .form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0 16px; }
        .check-field { display: flex; align-items: center; gap: 10px; margin: 8px 0 20px; font-size: 14px; }
        .check-field input { width: auto; }
        .detail-side { gap: 20px; }
        .detail-list { display: grid; gap: 12px; margin: 0; }
        .detail-list div { display: flex; justify-content: space-between; gap: 12px; border-bottom: 1px solid #edf1ee; padding-bottom: 10px; }
        .detail-list dt { color: #66736b; }
        .detail-list dd { margin: 0; font-weight: 700; text-align: right; }
        .conversation-full { margin: 0; white-space: pre-wrap; word-break: break-word; font: 12px/1.7 ui-monospace, SFMono-Regular, Consolas, monospace; }
        @media (max-width: 900px) {
            .shell { grid-template-columns: 1fr; }
            .sidebar { position: relative; height: auto; }
            .main { padding: 22px; }
            .stats, .image-grid { grid-template-columns: 1fr; }
            .topbar { align-items: flex-start; flex-direction: column; }
            .lead-header { flex-direction: column; }
            .detail-grid, .form-grid { grid-template-columns: 1fr; }
            table { min-width: 760px; }
        }
    </style>
</head>
<body>
    <div class="shell">
        <aside class="sidebar">
            <a class="brand" href="{{ route('admin.dashboard') }}">
                <div class="mark" aria-hidden="true">
                    <svg viewBox="0 0 48 48" fill="none">
                        <path d="M23.7 36.5c0-10.1 5.9-18.2 16.1-22.7.9-.4 1.9.3 1.8 1.3C40.5 27.6 33 35.2 23.7 36.5Z" fill="#FFFFFF"/>
                        <path d="M22.7 36.4C18 26.8 10.3 22.1 5.8 20.2c-.9-.4-1-1.7-.1-2.2 9.7-5.2 20.3-.4 25.6 9.1" stroke="#DDF6E6" stroke-width="3" stroke-linecap="round"/>
                        <path d="M24 38V10" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/>
                        <path d="M24 10l6 6M24 10l-6 6" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <div>
                    <strong>Saleh</strong>
                    <span>Basahel</span>
                </div>
            </a>
            <nav class="nav">
                @foreach ($navItems as $item)
                    <a class="{{ $active === $item['key'] ? 'active' : '' }}" href="{{ $item['route'] }}">{{ $item['label'] }}</a>
                @endforeach
            </nav>
            <form class="logout" method="post" action="{{ route('admin.logout') }}">
                @csrf
                <button type="submit">Logout</button>
            </form>
        </aside>
        <main class="main">
            <div class="topbar">
                <div>
                    <p class="muted" style="margin: 0 0 8px;">Admin Panel</p>
                    <h1>{{ $title ?? 'Dashboard' }}</h1>
                </div>
                <a class="visit" href="{{ url('/en') }}" target="_blank">View Website</a>
            </div>

            @if (session('status'))
                <div class="notice">{{ session('status') }}</div>
            @endif

            {{ $slot }}
        </main>
    </div>
</body>
</html>
