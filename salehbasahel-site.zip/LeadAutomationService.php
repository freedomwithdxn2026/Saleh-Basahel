<?php

namespace App\Services;

use App\Models\Lead;

class LeadAutomationService
{
    public function __construct(
        private OpenClawMessenger $messenger,
        private LeadEmailMessenger $email,
        private LeadWelcomeService $welcome,
    ) {
    }

    public function run(): array
    {
        return [
            'pending_welcomes' => $this->sendPendingWelcomes(),
            'daily_guidance' => $this->sendDueDailyGuidance(),
            'follow_ups' => $this->sendDueFollowUps(),
            'reminders' => $this->sendDueMeetingReminders(),
            'admin_notifications' => $this->sendAdminNotifications(),
        ];
    }

    private function sendPendingWelcomes(): int
    {
        $sent = 0;

        Lead::query()
            ->where('consent', true)
            ->whereNotNull('automation_enrolled_at')
            ->where(function ($query): void {
                $query
                    ->where(function ($query): void {
                        $query->whereNotNull('phone')->whereNull('welcome_whatsapp_sent_at');
                    })
                    ->orWhere(function ($query): void {
                        $query->whereNotNull('email')->whereNull('welcome_email_sent_at');
                    });
            })
            ->oldest('automation_enrolled_at')
            ->limit(50)
            ->get()
            ->each(function (Lead $lead) use (&$sent): void {
                $result = $this->welcome->sendPendingWelcome($lead);
                $sent += (int) $result['whatsapp'] + (int) $result['email'];
            });

        return $sent;
    }

    private function sendDueDailyGuidance(): int
    {
        $sent = 0;

        Lead::query()
            ->where('consent', true)
            ->whereNotNull('automation_enrolled_at')
            ->whereNotNull('next_guidance_at')
            ->where('next_guidance_at', '<=', now())
            ->where('guidance_step', '<', 7)
            ->whereNotIn('meeting_status', ['scheduled', 'completed', 'cancelled'])
            ->where('status', '!=', 'converted')
            ->orderBy('next_guidance_at')
            ->limit(50)
            ->get()
            ->each(function (Lead $lead) use (&$sent): void {
                $step = $lead->guidance_step + 1;
                $message = $this->guidanceMessage($lead, $step);
                $delivered = false;

                if ($lead->phone && $this->messenger->send($lead->phone, $message)) {
                    $sent++;
                    $delivered = true;
                }

                if ($lead->email && $this->email->send(
                    $lead->email,
                    'A practical next step for you',
                    $message,
                )) {
                    $sent++;
                    $delivered = true;
                }

                if (! $delivered) {
                    return;
                }

                $lead->guidance_step = $step;
                $lead->last_guidance_at = now();
                $lead->next_guidance_at = $step < 7 ? now()->addDay() : null;
                $lead->save();
            });

        return $sent;
    }

    private function sendDueFollowUps(): int
    {
        $sent = 0;

        Lead::query()
            ->where('consent', true)
            ->whereNotNull('phone')
            ->whereNotNull('next_follow_up_at')
            ->where('next_follow_up_at', '<=', now())
            ->where('follow_up_step', '<', 4)
            ->whereNotIn('meeting_status', ['scheduled', 'completed', 'cancelled'])
            ->orderBy('next_follow_up_at')
            ->limit(50)
            ->get()
            ->each(function (Lead $lead) use (&$sent): void {
                $step = $lead->follow_up_step + 1;
                $message = $this->followUpMessage($lead, $step);

                if (! $this->messenger->send($lead->phone, $message)) {
                    return;
                }

                $lead->follow_up_step = $step;
                $lead->last_follow_up_at = now();
                $lead->next_follow_up_at = match ($step) {
                    1 => now()->addDays(2),
                    2 => now()->addDays(4),
                    3 => now()->addDays(7),
                    default => null,
                };
                $lead->save();
                $sent++;
            });

        return $sent;
    }

    private function sendDueMeetingReminders(): int
    {
        $sent = 0;

        Lead::query()
            ->whereNotNull('phone')
            ->where('meeting_status', 'scheduled')
            ->whereBetween('meeting_scheduled_at', [now()->subMinutes(5), now()->addHours(25)])
            ->get()
            ->each(function (Lead $lead) use (&$sent): void {
                $minutes = now()->diffInMinutes($lead->meeting_scheduled_at, false);
                $key = match (true) {
                    $minutes >= 1425 && $minutes <= 1455 => '24h',
                    $minutes >= 50 && $minutes <= 70 => '1h',
                    $minutes >= 5 && $minutes <= 15 => '10m',
                    default => null,
                };

                $alreadySent = collect($lead->reminders_sent ?? [])->contains($key);
                if (! $key || $alreadySent || ! $this->messenger->send($lead->phone, $this->reminderMessage($lead, $key))) {
                    return;
                }

                $lead->reminders_sent = collect($lead->reminders_sent ?? [])->push($key)->unique()->values()->all();
                $lead->save();
                $sent++;
            });

        return $sent;
    }

    private function sendAdminNotifications(): int
    {
        $adminNumber = config('services.openclaw.admin_whatsapp');
        if (! $adminNumber) {
            return 0;
        }

        $sent = 0;
        Lead::query()
            ->where('updated_at', '>=', now()->subMinutes(15))
            ->latest('updated_at')
            ->limit(100)
            ->get()
            ->each(function (Lead $lead) use ($adminNumber, &$sent): void {
            $stage = match (true) {
                $lead->meeting_status === 'completed' => 'completed',
                $lead->meeting_status === 'scheduled' => 'scheduled',
                $lead->status === 'qualified' || in_array($lead->lead_temperature, ['warm', 'hot'], true) => 'qualified',
                default => 'new',
            };

            $sentStages = collect($lead->admin_notifications_sent ?? []);
            if ($sentStages->contains($stage)) {
                return;
            }

            $message = "Lead update: {$lead->name} is now {$stage}. Source: {$lead->source_label}.";
            if (! $this->messenger->send($adminNumber, $message)) {
                return;
            }

            $lead->admin_notifications_sent = $sentStages->push($stage)->unique()->values()->all();
            $lead->save();
            $sent++;
            });

        return $sent;
    }

    private function followUpMessage(Lead $lead, int $step): string
    {
        $name = $this->firstName($lead);

        return match ($step) {
            1 => "Hi {$name}, just checking in. Did you get a chance to think about what we discussed?",
            2 => "Hi {$name}, I was thinking about our previous conversation. Would you still like to learn more?",
            3 => "Hi {$name}, hope everything is going well. If you're still exploring options or have questions, I'm happy to help.",
            default => "Hi {$name}, just wanted to check in one last time. Whenever the timing feels right, feel free to reach out.",
        };
    }

    private function reminderMessage(Lead $lead, string $key): string
    {
        $name = $this->firstName($lead);

        return match ($key) {
            '24h' => "Hi {$name}, hope you're doing well. Just a quick reminder about your scheduled meeting tomorrow. Looking forward to speaking with you.",
            '1h' => "Hi {$name}, just a friendly reminder that our meeting is coming up shortly. See you soon.",
            default => "Hi {$name}, looking forward to our conversation in a few minutes.",
        };
    }

    private function guidanceMessage(Lead $lead, int $step): string
    {
        $name = $this->firstName($lead);
        $calendly = config('services.calendly.url');

        return match ($step) {
            1 => "Hi {$name}, a useful first step is to write down one clear goal you would like to improve. Keeping it specific makes the next step easier.",
            2 => "Hi {$name}, small routines usually work better than big promises. What is one simple habit you could repeat for the next seven days?",
            3 => "Hi {$name}, progress often starts with one practical skill. Communication, consistency, and time management are all strong places to begin.",
            4 => "Hi {$name}, it helps to choose a realistic amount of time each week for learning and personal growth, even if it is only a few focused hours.",
            5 => "Hi {$name}, before making any decision, prepare the questions that matter most to you. Clear questions lead to a more useful private conversation.",
            6 => "Hi {$name}, consistency matters more than speed. A steady learning routine can help you understand what fits your goals and current commitments.",
            default => "Hi {$name}, if you would like clear information and a private conversation, you can choose a convenient time here: {$calendly}",
        };
    }

    private function firstName(Lead $lead): string
    {
        return str((string) ($lead->name ?: 'there'))->before(' ')->toString();
    }
}
