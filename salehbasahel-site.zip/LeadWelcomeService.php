<?php

namespace App\Services;

use App\Models\Lead;

class LeadWelcomeService
{
    public function __construct(
        private OpenClawMessenger $whatsapp,
        private LeadEmailMessenger $email,
    ) {
    }

    public function enroll(Lead $lead): array
    {
        if (! $lead->consent || $lead->source !== 'landing_page') {
            return ['whatsapp' => false, 'email' => false];
        }

        $lead->automation_enrolled_at ??= now();
        $lead->next_follow_up_at = now()->addDays(8);
        $lead->save();

        return $this->sendPendingWelcome($lead);
    }

    public function sendPendingWelcome(Lead $lead): array
    {
        $sent = ['whatsapp' => false, 'email' => false];

        if (! $lead->consent || ! $lead->automation_enrolled_at) {
            return $sent;
        }

        if ($lead->phone && ! $lead->welcome_whatsapp_sent_at) {
            $sent['whatsapp'] = $this->whatsapp->send($lead->phone, $this->welcomeMessage($lead));

            if ($sent['whatsapp']) {
                $lead->welcome_whatsapp_sent_at = now();
            }
        }

        if ($lead->email && ! $lead->welcome_email_sent_at && $this->email->isConfigured()) {
            $sent['email'] = $this->email->send(
                $lead->email,
                'Welcome, '.$this->firstName($lead).' - your next steps',
                $this->welcomeEmailMessage($lead),
            );

            if ($sent['email']) {
                $lead->welcome_email_sent_at = now();
            }
        }

        if (($sent['whatsapp'] || $sent['email']) && ! $lead->next_guidance_at) {
            $lead->next_guidance_at = now()->addDay();
        }

        $lead->save();

        return $sent;
    }

    private function welcomeMessage(Lead $lead): string
    {
        $name = $this->firstName($lead);

        return "Hi {$name}, thanks for reaching out to Saleh Basahel. We received your details and will follow up privately with guidance based on your interest. You can reply here anytime with a question.";
    }

    private function welcomeEmailMessage(Lead $lead): string
    {
        $name = $this->firstName($lead);

        return implode("\n\n", [
            "Hi {$name},",
            'Thanks for reaching out to Saleh Basahel. We received your details and will follow up privately with guidance based on your interest.',
            'There is no pressure and no guaranteed outcome. The goal is to help you understand your next practical step.',
            'You can reply to this email or message us on WhatsApp whenever you have a question.',
        ]);
    }

    private function firstName(Lead $lead): string
    {
        return str((string) ($lead->name ?: 'there'))->before(' ')->toString();
    }
}
