<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Throwable;

class LeadEmailMessenger
{
    public function isConfigured(): bool
    {
        return ! in_array(config('mail.default'), ['array', 'log'], true)
            && config('mail.from.address')
            && config('mail.from.address') !== 'hello@example.com';
    }

    public function send(string $target, string $subject, string $message): bool
    {
        if (! $this->isConfigured()) {
            return false;
        }

        try {
            Mail::raw($message, function ($mail) use ($target, $subject): void {
                $mail->to($target)->subject($subject);
            });

            return true;
        } catch (Throwable $exception) {
            Log::warning('Lead email send failed.', [
                'target' => $target,
                'error' => $exception->getMessage(),
            ]);

            return false;
        }
    }
}
