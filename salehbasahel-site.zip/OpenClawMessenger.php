<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Symfony\Component\Process\Process;
use Throwable;

class OpenClawMessenger
{
    public function send(string $target, string $message): bool
    {
        if (! config('services.openclaw.messaging_enabled', false) || PHP_OS_FAMILY === 'Windows') {
            return false;
        }

        $binary = config('services.openclaw.binary', '/home/openclaw/.local/bin/openclaw');
        $user = config('services.openclaw.user', 'openclaw');
        $home = config('services.openclaw.home', '/home/openclaw');
        $path = config('services.openclaw.path', '/home/openclaw/.local/bin:/usr/local/bin:/usr/bin:/bin');

        try {
            $process = new Process([
                'sudo',
                '-u',
                $user,
                'env',
                "HOME={$home}",
                "PATH={$path}",
                $binary,
                'message',
                'send',
                '--channel',
                'whatsapp',
                '--target',
                $target,
                '--message',
                $message,
                '--json',
            ]);
            $process->setTimeout(45);
            $process->run();

            if (! $process->isSuccessful()) {
                Log::warning('OpenClaw WhatsApp send failed.', [
                    'target' => $target,
                    'error' => trim($process->getErrorOutput()),
                ]);
            }

            return $process->isSuccessful();
        } catch (Throwable $exception) {
            Log::warning('OpenClaw WhatsApp send exception.', [
                'target' => $target,
                'error' => $exception->getMessage(),
            ]);

            return false;
        }
    }
}
