<x-admin.layout title="Manage Lead" active="leads">
    <div class="lead-detail-head">
        <a class="text-link" href="{{ route('admin.leads.index') }}">&larr; Back to leads</a>
        <div class="action-buttons">
            <span class="temperature-badge temperature-{{ $lead->lead_temperature }}">{{ $lead->temperature_label }}</span>
            <span class="status-badge">{{ $lead->lead_score }} / 100</span>
            <form method="post" action="{{ route('admin.leads.destroy', $lead) }}" onsubmit="return confirm('Delete this lead permanently? This action cannot be undone.')">
                @csrf
                @method('DELETE')
                <button class="btn btn-small btn-danger" type="submit">Delete Lead</button>
            </form>
        </div>
    </div>

    <div class="detail-grid">
        <form class="card pad" method="post" action="{{ route('admin.leads.update', $lead) }}">
            @csrf
            <p class="eyebrow">Lead Record</p>
            <h2 style="margin-top: 0;">{{ $lead->name }}</h2>

            <div class="form-grid">
                <div class="field"><label for="name">Full name</label><input id="name" name="name" value="{{ old('name', $lead->name) }}" required></div>
                <div class="field"><label for="phone">Phone</label><input id="phone" name="phone" value="{{ old('phone', $lead->phone) }}"></div>
                <div class="field"><label for="email">Email</label><input id="email" type="email" name="email" value="{{ old('email', $lead->email) }}"></div>
                <div class="field"><label for="country">Country</label><input id="country" name="country" value="{{ old('country', $lead->country) }}"></div>
                <div class="field"><label for="occupation">Occupation</label><input id="occupation" name="occupation" value="{{ old('occupation', $lead->occupation) }}"></div>
                <div class="field"><label for="interest">Interest</label><input id="interest" name="interest" value="{{ old('interest', $lead->interest) }}"></div>
                <div class="field"><label for="status">Lead status</label><select id="status" name="status">@foreach (['new', 'qualified', 'follow_up_needed', 'meeting_scheduled', 'converted', 'closed'] as $option)<option value="{{ $option }}" @selected(old('status', $lead->status) === $option)>{{ str($option)->replace('_', ' ')->title() }}</option>@endforeach</select></div>
                <div class="field"><label for="meeting_status">Meeting status</label><select id="meeting_status" name="meeting_status">@foreach (['not_scheduled', 'scheduled', 'completed', 'cancelled'] as $option)<option value="{{ $option }}" @selected(old('meeting_status', $lead->meeting_status) === $option)>{{ str($option)->replace('_', ' ')->title() }}</option>@endforeach</select></div>
                <div class="field"><label for="meeting_scheduled_at">Meeting date and time</label><input id="meeting_scheduled_at" type="datetime-local" name="meeting_scheduled_at" value="{{ old('meeting_scheduled_at', $lead->meeting_scheduled_at?->format('Y-m-d\TH:i')) }}"></div>
                <label class="check-field"><input type="checkbox" name="consent" value="1" @checked(old('consent', $lead->consent))> Consent received for private follow-up</label>
            </div>

            <div class="field"><label for="notes">Admin notes</label><textarea id="notes" name="notes">{{ old('notes', $lead->notes) }}</textarea></div>
            <button class="btn" type="submit">Save Lead</button>
        </form>

        <aside class="grid detail-side">
            <div class="card pad">
                <p class="eyebrow">Automation</p>
                <dl class="detail-list">
                    <div><dt>Source</dt><dd>{{ $lead->source_label }}</dd></div>
                    <div><dt>Next follow-up</dt><dd>{{ $lead->next_follow_up_at?->format('M d, Y H:i') ?? 'Not scheduled' }}</dd></div>
                    <div><dt>Follow-up step</dt><dd>{{ $lead->follow_up_step }} / 4</dd></div>
                    <div><dt>Calendly</dt><dd>{{ str($lead->calendly_status)->replace('_', ' ')->title() }}</dd></div>
                    <div><dt>Created</dt><dd>{{ $lead->created_at?->format('M d, Y H:i') }}</dd></div>
                </dl>
            </div>
            <div class="card pad"><p class="eyebrow">Conversation History</p><pre class="conversation-full">{{ $lead->conversation_history ?: $lead->message ?: 'No conversation saved yet.' }}</pre></div>
        </aside>
    </div>
</x-admin.layout>
