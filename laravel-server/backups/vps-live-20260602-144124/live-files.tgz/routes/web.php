<?php

use App\Http\Controllers\LeadController;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/en')->name('home');

Route::pattern('locale', 'en|ar');
Route::pattern('section', 'video-overview|how-it-works|success-stories|wellness-lifestyle|business-opportunity|about-saleh|faq|contact');

Route::get('/{locale}/{section?}', function (string $locale, ?string $section = null) {
    App::setLocale($locale);
    session(['locale' => $locale]);

    return view('saleh-basahel-landing-page', [
        'locale' => $locale,
        'isRtl' => $locale === 'ar',
        'section' => $section,
    ]);
})->name('home.localized');

Route::post('/{locale}/leads', [LeadController::class, 'store'])->name('leads.store');
