@php
    $locale = $locale ?? app()->getLocale();
    $isRtl = $isRtl ?? $locale === 'ar';
    $section = $section ?? null;
    $nav = __('site.nav');
@endphp

<!doctype html>
<html lang="{{ $locale }}" dir="{{ $isRtl ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="{{ __('site.meta.description') }}">
    <link rel="canonical" href="{{ url('/' . $locale . ($section ? '/' . $section : '')) }}">
    <link rel="alternate" hreflang="en" href="{{ url('/en' . ($section ? '/' . $section : '')) }}">
    <link rel="alternate" hreflang="ar" href="{{ url('/ar' . ($section ? '/' . $section : '')) }}">
    <link rel="icon" type="image/png" href="{{ asset('favcon.png') }}">
    <link rel="shortcut icon" type="image/png" href="{{ asset('favcon.png') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link
        rel="preload"
        as="image"
        href="{{ asset('images/hero-aside-image-1280.webp') }}"
        imagesrcset="{{ asset('images/hero-aside-image-768.webp') }} 768w, {{ asset('images/hero-aside-image-1280.webp') }} 1280w, {{ asset('images/hero-aside-image-1731.webp') }} 1731w"
        imagesizes="(min-width: 1024px) 44vw, 100vw"
        fetchpriority="high"
    >
    <title>{{ __('site.meta.title') }}</title>
    <script>
        tailwind = {
            config: {
                theme: {
                    extend: {
                        colors: {
                            brand: {
                                DEFAULT: '#1E9447',
                                dark: '#16763A',
                                light: '#EAF8EF',
                            },
                            ink: '#111111',
                            muted: '#666666',
                            line: '#E5E5E5',
                        },
                        fontFamily: {
                            sans: ['Montserrat', 'ui-sans-serif', 'system-ui', 'Arial', 'sans-serif'],
                            arabic: ['Montserrat', 'Tahoma', 'Arial', 'sans-serif'],
                        },
                    },
                },
            },
        };
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        html {
            scroll-behavior: smooth;
        }

        [x-cloak] {
            display: none !important;
        }

        .hero-visual {
            background:
                radial-gradient(circle at 20% 20%, rgba(30, 148, 71, 0.18), transparent 34%),
                linear-gradient(135deg, #ffffff, #eef8f1);
        }

        @keyframes support-box-shake {
            0%, 100% {
                transform: rotate(0deg) translateY(0);
            }

            20% {
                transform: rotate(-0.35deg) translateY(-1px);
            }

            40% {
                transform: rotate(0.35deg) translateY(1px);
            }

            60% {
                transform: rotate(-0.25deg) translateY(0);
            }

            80% {
                transform: rotate(0.25deg) translateY(-1px);
            }
        }

        .support-box-shake {
            animation: support-box-shake 2.8s ease-in-out infinite;
            transform-origin: center;
        }

        @keyframes section-reveal {
            from {
                opacity: 0;
                transform: translateY(24px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .reveal-up {
            animation: section-reveal 0.75s ease both;
            animation-timeline: view();
            animation-range: entry 0% cover 28%;
        }

        @keyframes reveal-from-left {
            from {
                opacity: 0;
                transform: translateX(-64px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes reveal-from-right {
            from {
                opacity: 0;
                transform: translateX(64px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .reveal-left {
            animation: reveal-from-left 0.85s cubic-bezier(0.22, 1, 0.36, 1) both;
            animation-timeline: view();
            animation-range: entry 0% cover 30%;
        }

        .reveal-right {
            animation: reveal-from-right 0.85s cubic-bezier(0.22, 1, 0.36, 1) both;
            animation-timeline: view();
            animation-range: entry 0% cover 30%;
        }

        .section-clip-x {
            overflow-x: clip;
        }

        @media (prefers-reduced-motion: reduce) {
            .support-box-shake {
                animation: none;
            }

            .reveal-up,
            .reveal-left,
            .reveal-right {
                animation: none;
            }
        }
    </style>
</head>
<body class="{{ $isRtl ? 'font-arabic' : 'font-sans' }} bg-white text-ink antialiased">
    <x-header :locale="$locale" :nav="$nav" :initial-section="$section" />

    <main>
        <section id="hero" class="min-h-screen bg-[#EAF8EF] px-5 pt-24 pb-10 text-[#111111] sm:px-8 sm:pt-28 sm:pb-12 lg:px-16 lg:pt-28 lg:pb-12">
            <div class="mx-auto grid min-h-[calc(100vh-10rem)] w-full max-w-7xl items-center gap-8 lg:grid-cols-[1.05fr_0.9fr] lg:gap-10">
                <div class="max-w-3xl">
                    <div class="inline-flex items-center gap-3 rounded-full border border-white/80 bg-white/45 px-4 py-2 text-sm font-normal text-[#111111] shadow-sm">
                        <span class="h-3 w-3 rounded-full bg-[#1E9447] shadow-[0_0_0_8px_rgba(30,148,71,0.12)]"></span>
                        {{ __('site.hero.trust_badge') }}
                    </div>
                    <h1 class="mt-6 max-w-3xl text-4xl font-semibold leading-[1.14] tracking-normal text-[#111111] sm:text-5xl lg:text-[3rem]">
                        {{ __('site.hero.title') }}
                    </h1>
                    <p class="mt-5 max-w-2xl text-[17px] leading-8 text-[#303030] sm:text-lg">
                        {{ __('site.hero.subtitle') }}
                    </p>
                    <div class="mt-7 grid max-w-xl grid-cols-1 gap-4 sm:grid-cols-2">
                        @foreach (__('site.hero.features') as $feature)
                            <div class="flex min-h-14 items-center justify-center rounded-lg border border-[#D9E9DE] bg-white/70 px-5 text-center text-base font-normal text-[#111111] shadow-sm">
                                {{ $feature }}
                            </div>
                        @endforeach
                    </div>
                    <div class="mt-7">
                        <a
                            href="{{ url('/' . $locale . '/video-overview') }}"
                            onclick="event.preventDefault(); document.getElementById('video-overview')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); history.pushState(null, '', this.href);"
                            class="inline-flex min-h-[52px] items-center justify-center rounded-full bg-[#1E9447] px-8 text-base font-bold text-white shadow-lg shadow-[#1E9447]/25 transition duration-300 hover:scale-105 hover:bg-[#16763A] hover:shadow-xl hover:shadow-[#1E9447]/30 focus:outline-none focus:ring-4 focus:ring-[#1E9447]/25"
                        >
                            {{ __('site.cta.overview') }}
                        </a>
                    </div>
                </div>

                <div>
                    <div class="overflow-hidden rounded-[24px] bg-white shadow-2xl shadow-[#16763A]/10">
                        <div class="relative aspect-[1731/909] w-full overflow-hidden rounded-[24px] bg-white">
                            <picture class="absolute inset-0 block h-full w-full">
                                <source
                                    type="image/webp"
                                    srcset="{{ asset('images/hero-aside-image-768.webp') }} 768w, {{ asset('images/hero-aside-image-1280.webp') }} 1280w, {{ asset('images/hero-aside-image-1731.webp') }} 1731w"
                                    sizes="(min-width: 1024px) 44vw, 100vw"
                                >
                                <img
                                    src="{{ asset('images/hero-aside-image-1280.jpg') }}"
                                    srcset="{{ asset('images/hero-aside-image-768.jpg') }} 768w, {{ asset('images/hero-aside-image-1280.jpg') }} 1280w, {{ asset('images/hero-aside-image-1731.jpg') }} 1731w"
                                    sizes="(min-width: 1024px) 44vw, 100vw"
                                    width="1731"
                                    height="909"
                                    alt="{{ __('site.hero.image_alt') }}"
                                    loading="eager"
                                    decoding="async"
                                    fetchpriority="high"
                                    class="h-full w-full object-contain object-center"
                                >
                            </picture>
                        </div>
                    </div>
                    <p class="mt-5 text-center text-sm text-[#111111]">{{ __('site.hero.fine_print') }}</p>
                </div>
            </div>
        </section>

        <section id="video-overview" class="scroll-mt-28 bg-[#FBFAF5] px-5 py-20 sm:px-8 lg:px-16">
            <div class="mx-auto w-full max-w-7xl">
                <div class="mx-auto max-w-4xl text-center">
                    <p class="mb-4 text-sm font-semibold uppercase tracking-[0.16em] text-[#16763A]">{{ __('site.video.eyebrow') }}</p>
                    <h2 class="text-3xl font-bold tracking-normal text-[#111111] sm:text-4xl">{{ __('site.video.title') }}</h2>
                    <p class="mx-auto mt-5 max-w-3xl text-lg leading-8 text-[#111111]">{{ __('site.video.description') }}</p>
                </div>

                <div class="mx-auto mt-12 max-w-5xl rounded-[18px] bg-gradient-to-r from-[#1E9447] via-[#16763A] to-[#F5A623] p-[2px] shadow-2xl shadow-[#16763A]/15">
                    <video
                        class="aspect-video w-full rounded-[16px] bg-black object-cover"
                        controls
                        controlslist="nodownload noplaybackrate"
                        disablepictureinpicture
                        playsinline
                        preload="none"
                        poster="{{ asset('images/video-overview-poster.svg') }}"
                        oncontextmenu="return false"
                        onclick="this.paused ? this.play() : this.pause()"
                        aria-label="{{ __('site.video.title') }}"
                    >
                        <source src="{{ asset('videos/free-overview.mp4') }}" type="video/mp4">
                        {{ __('site.video.fallback') }}
                    </video>
                </div>

                <div
                    x-data="{ open: false }"
                    :class="open ? '' : 'support-box-shake'"
                    class="mx-auto mt-8 max-w-5xl rounded-[18px] border border-[#B9E6C8] bg-white text-center shadow-xl shadow-[#16763A]/10 transition duration-300"
                >
                    <button
                        type="button"
                        class="group flex w-full flex-col items-center justify-center gap-5 rounded-[18px] p-6 text-center focus:outline-none focus:ring-4 focus:ring-[#1E9447]/20"
                        :aria-expanded="open.toString()"
                        aria-controls="special-support-content"
                        @click="open = !open"
                    >
                        <div class="text-center">
                            <p class="text-xs font-semibold uppercase tracking-[0.16em] text-[#16763A]">{{ __('site.video.gift_eyebrow') }}</p>
                            <h3 class="mt-3 text-2xl font-bold text-[#111111]">{{ __('site.video.gift_title') }}</h3>
                        </div>
                        <span
                            class="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[#FFF4DA] text-[#1E9447] transition duration-300 group-hover:scale-105 group-hover:bg-[#EAF8EF]"
                            aria-hidden="true"
                        >
                            <svg viewBox="0 0 24 24" class="h-8 w-8" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 12v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-8"/>
                                <path d="M2 7h20v5H2z"/>
                                <path d="M12 7v14"/>
                                <path d="M12 7H7.5A2.5 2.5 0 1 1 10 4.5C10 6 12 7 12 7Z"/>
                                <path d="M12 7h4.5A2.5 2.5 0 1 0 14 4.5C14 6 12 7 12 7Z"/>
                            </svg>
                        </span>
                    </button>

                    <div
                        id="special-support-content"
                        x-cloak
                        x-show="open"
                        x-transition:enter="transition ease-out duration-300"
                        x-transition:enter-start="opacity-0 -translate-y-3"
                        x-transition:enter-end="opacity-100 translate-y-0"
                        x-transition:leave="transition ease-in duration-200"
                        x-transition:leave-start="opacity-100 translate-y-0"
                        x-transition:leave-end="opacity-0 -translate-y-3"
                        class="px-6 pb-6"
                    >
                        <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                            @foreach (__('site.video.gift_items') as $item)
                                <div class="flex min-h-16 items-center justify-center rounded-lg border border-[#E5E5E5] bg-[#FBFCFA] px-4 text-center text-sm font-medium text-[#111111]">
                                    {{ $item }}
                                </div>
                            @endforeach
                        </div>

                        <div class="mt-6 flex flex-col items-center gap-5 border-t border-[#E5E5E5] pt-6 text-center">
                            <p class="mx-auto max-w-3xl text-sm leading-7 text-[#666666]">{{ __('site.video.gift_note') }}</p>
                            <a href="{{ url('/' . $locale . '/contact') }}" class="inline-flex min-h-12 shrink-0 items-center justify-center rounded-full bg-[#1E9447] px-7 text-sm font-bold text-white shadow-lg shadow-[#1E9447]/25 transition duration-300 hover:scale-105 hover:bg-[#16763A] focus:outline-none focus:ring-4 focus:ring-[#1E9447]/25">
                                {{ __('site.video.gift_cta') }}
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="how-it-works" class="scroll-mt-28 bg-white px-5 py-20 sm:px-8 lg:px-16">
            <div class="mx-auto w-full max-w-7xl">
                <div class="mx-auto max-w-3xl text-center">
                    <p class="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-brand">{{ __('site.sections.how.eyebrow') }}</p>
                    <h2 class="text-3xl font-bold leading-tight tracking-normal text-ink sm:text-4xl">{{ __('site.sections.how.title') }}</h2>
                    <p class="mt-5 text-lg leading-8 text-muted">{{ __('site.sections.how.body') }}</p>
                </div>
                <div class="mt-10 grid gap-5 md:grid-cols-3">
                    @foreach (__('site.sections.how.steps') as $step)
                        <div class="rounded-lg border border-line bg-white p-6 text-center shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl">
                            <h3 class="text-xl font-semibold text-ink">{{ $step['title'] }}</h3>
                            <p class="mt-3 leading-7 text-muted">{{ $step['body'] }}</p>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>

        <section id="success-stories" class="scroll-mt-28 overflow-hidden bg-brand-light px-5 py-20 sm:px-8 lg:px-16">
            @php
                $storyTestimonials = __('site.sections.stories.testimonials');
                $storyTrustNote = __('site.sections.stories.trust_note');

                if (! is_array($storyTestimonials)) {
                    $storyTestimonials = trans('site.sections.stories.testimonials', [], 'en');
                }

                if ($storyTrustNote === 'site.sections.stories.trust_note') {
                    $storyTrustNote = trans('site.sections.stories.trust_note', [], 'en');
                }
            @endphp
            <div class="mx-auto w-full max-w-7xl text-center">
                <div class="mx-auto max-w-4xl reveal-up">
                    <p class="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-brand-dark">{{ __('site.sections.stories.eyebrow') }}</p>
                    <h2 class="mx-auto max-w-5xl text-center text-3xl font-bold leading-tight tracking-normal text-ink [text-wrap:balance] sm:text-4xl">{{ __('site.sections.stories.title') }}</h2>
                    <p class="mx-auto mt-5 max-w-3xl text-lg leading-8 text-muted">{{ __('site.sections.stories.body') }}</p>
                </div>

                <div class="mt-12 grid gap-6 md:grid-cols-3">
                    @foreach ($storyTestimonials as $testimonial)
                        <article class="reveal-up group rounded-[18px] border border-white bg-white p-6 text-center shadow-lg shadow-[#16763A]/5 transition duration-300 hover:-translate-y-2 hover:shadow-2xl hover:shadow-[#16763A]/10" style="animation-delay: {{ 180 + ($loop->index * 110) }}ms">
                            <div class="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-[#1E9447] to-[#16763A] text-lg font-extrabold text-white shadow-lg shadow-[#16763A]/20">
                                {{ $testimonial['initials'] }}
                            </div>
                            <div class="mt-4 flex justify-center gap-1 text-[#F5A623]" aria-label="{{ $testimonial['rating_label'] }}">
                                @for ($i = 0; $i < 5; $i++)
                                    <span aria-hidden="true">★</span>
                                @endfor
                            </div>
                            <p class="mt-4 text-lg font-semibold text-ink">{{ $testimonial['headline'] }}</p>
                            <p class="mt-4 leading-7 text-muted">{{ $testimonial['body'] }}</p>
                            <div class="mt-6 rounded-lg bg-brand-light px-4 py-3">
                                <p class="text-sm font-bold text-brand-dark">{{ $testimonial['metric'] }}</p>
                            </div>
                            <div class="mt-5 border-t border-line pt-4">
                                <p class="font-semibold text-ink">{{ $testimonial['name'] }}</p>
                                <p class="mt-1 text-sm text-muted">{{ $testimonial['role'] }}</p>
                            </div>
                        </article>
                    @endforeach
                </div>

                <div class="reveal-up mx-auto mt-10 max-w-4xl rounded-[18px] border border-[#B9E6C8] bg-white/80 p-6 text-center shadow-xl shadow-[#16763A]/10">
                    <p class="text-base leading-8 text-muted">{{ $storyTrustNote }}</p>
                </div>
            </div>
        </section>

        <section id="wellness-lifestyle" class="section-clip-x scroll-mt-28 bg-white px-5 py-20 sm:px-8 lg:px-16 lg:py-24">
            @php
                $wellnessCards = __('site.sections.wellness.cards');
                $wellnessImageAlt = __('site.sections.wellness.image_alt');

                if (! is_array($wellnessCards)) {
                    $wellnessCards = trans('site.sections.wellness.cards', [], 'en');
                }

                if ($wellnessImageAlt === 'site.sections.wellness.image_alt') {
                    $wellnessImageAlt = trans('site.sections.wellness.image_alt', [], 'en');
                }
            @endphp
            <div class="mx-auto w-full max-w-7xl">
                <div class="reveal-up mx-auto max-w-7xl text-center">
                    <p class="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-brand">{{ __('site.sections.wellness.eyebrow') }}</p>
                    <h2 class="mx-auto max-w-full text-center text-[clamp(1.9rem,2.35vw,2.35rem)] font-bold leading-tight tracking-normal text-ink [text-wrap:balance] xl:whitespace-nowrap">{{ __('site.sections.wellness.title') }}</h2>
                    <p class="mx-auto mt-5 max-w-4xl text-lg leading-8 text-muted">{{ __('site.sections.wellness.body') }}</p>
                </div>

                <div class="mt-12 grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
                    <div class="lg:self-stretch">
                        <div class="lg:sticky lg:top-28">
                            <div class="reveal-left overflow-hidden rounded-[24px] bg-brand-light shadow-2xl shadow-[#16763A]/10">
                                <picture class="block">
                                    <source
                                        type="image/webp"
                                        srcset="{{ asset('images/hero-aside-image-768.webp') }} 768w, {{ asset('images/hero-aside-image-1280.webp') }} 1280w, {{ asset('images/hero-aside-image-1731.webp') }} 1731w"
                                        sizes="(min-width: 1024px) 42vw, 100vw"
                                    >
                                    <img
                                        src="{{ asset('images/hero-aside-image-1280.jpg') }}"
                                        srcset="{{ asset('images/hero-aside-image-768.jpg') }} 768w, {{ asset('images/hero-aside-image-1280.jpg') }} 1280w, {{ asset('images/hero-aside-image-1731.jpg') }} 1731w"
                                        sizes="(min-width: 1024px) 42vw, 100vw"
                                        width="1731"
                                        height="909"
                                        alt="{{ $wellnessImageAlt }}"
                                        loading="lazy"
                                        decoding="async"
                                        class="aspect-[4/3] w-full object-cover object-center transition duration-500 hover:scale-[1.03]"
                                    >
                                </picture>
                            </div>
                        </div>
                    </div>

                    <div class="reveal-right grid gap-5 sm:grid-cols-2 lg:min-h-[980px] lg:auto-rows-fr">
                        @foreach ($wellnessCards as $card)
                            <article class="flex min-h-[260px] flex-col justify-center rounded-[18px] border border-line bg-white p-6 text-center shadow-lg shadow-black/5 transition duration-300 hover:-translate-y-1 hover:border-[#B9E6C8] hover:shadow-2xl hover:shadow-[#16763A]/10 lg:min-h-[320px]" style="animation-delay: {{ $loop->index * 90 }}ms">
                                <div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-brand-light text-brand">
                                    <svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                        <path d="M12 21c4.5-3.2 7-7.1 7-11.2A7 7 0 0 0 5 9.8C5 13.9 7.5 17.8 12 21Z"/>
                                        <path d="M9 10.5c1.6.2 2.7.9 3 2.3.3-1.4 1.4-2.1 3-2.3"/>
                                    </svg>
                                </div>
                                <h3 class="mt-4 text-xl font-semibold text-ink">{{ $card['title'] }}</h3>
                                <p class="mt-3 leading-7 text-muted">{{ $card['body'] }}</p>
                            </article>
                        @endforeach
                    </div>
                </div>
            </div>
        </section>

        <section id="business-opportunity" class="scroll-mt-28 bg-[#F8FAF8] px-5 py-20 sm:px-8 lg:px-16">
            <div class="mx-auto grid w-full max-w-7xl gap-10 text-center lg:grid-cols-2 lg:items-center">
                <div class="mx-auto max-w-3xl">
                    <p class="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-brand">{{ __('site.sections.business.eyebrow') }}</p>
                    <h2 class="text-3xl font-bold leading-tight tracking-normal text-ink sm:text-4xl">{{ __('site.sections.business.title') }}</h2>
                    <p class="mt-5 text-lg leading-8 text-muted">{{ __('site.sections.business.body') }}</p>
                </div>
                <div class="rounded-lg border border-line bg-white p-7 text-center shadow-sm">
                    <ul class="space-y-5">
                        @foreach (__('site.sections.business.points') as $point)
                            <li class="flex flex-col items-center gap-3">
                                <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-light text-sm font-black text-brand">✓</span>
                                <span class="text-center text-muted">{{ $point }}</span>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </section>

        <section id="about-saleh" class="scroll-mt-28 bg-white px-5 py-20 sm:px-8 lg:px-16">
            <div class="mx-auto w-full max-w-7xl">
                <div class="mx-auto max-w-3xl text-center">
                    <p class="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-brand">{{ __('site.sections.about.eyebrow') }}</p>
                    <h2 class="text-3xl font-bold leading-tight tracking-normal text-ink sm:text-4xl">{{ __('site.sections.about.title') }}</h2>
                    <p class="mt-5 text-lg leading-8 text-muted">{{ __('site.sections.about.body') }}</p>
                </div>
            </div>
        </section>

        <section id="faq" class="scroll-mt-28 bg-[#F8FAF8] px-5 py-20 sm:px-8 lg:px-16">
            <div class="mx-auto w-full max-w-7xl">
                <div class="mx-auto max-w-4xl text-center">
                    <div class="mb-10">
                        <p class="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-brand">{{ __('site.sections.faq.eyebrow') }}</p>
                        <h2 class="text-3xl font-bold leading-tight tracking-normal text-ink sm:text-4xl">{{ __('site.sections.faq.title') }}</h2>
                    </div>
                    <div class="divide-y divide-line rounded-lg border border-line bg-white">
                        @foreach (__('site.sections.faq.items') as $item)
                            <details class="group p-6">
                                <summary class="flex cursor-pointer list-none items-center justify-center gap-5 text-center text-lg font-semibold text-ink">
                                    {{ $item['q'] }}
                                    <span class="text-brand transition group-open:rotate-45">+</span>
                                </summary>
                                <p class="mt-4 text-center leading-7 text-muted">{{ $item['a'] }}</p>
                            </details>
                        @endforeach
                    </div>
                </div>
            </div>
        </section>

        <section id="contact" class="scroll-mt-28 bg-white px-5 py-20 sm:px-8 lg:px-16">
            <div class="mx-auto grid w-full max-w-7xl gap-10 text-center lg:grid-cols-[0.9fr_0.8fr] lg:items-start">
                <div class="mx-auto max-w-3xl">
                    <p class="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-brand">{{ __('site.form.eyebrow') }}</p>
                    <h2 class="text-3xl font-bold leading-tight tracking-normal text-ink sm:text-4xl">{{ __('site.form.title') }}</h2>
                    <p class="mt-5 text-lg leading-8 text-muted">{{ __('site.form.body') }}</p>
                    <p class="mt-6 rounded-lg border-s-4 border-brand bg-brand-light p-5 leading-7 text-muted">{{ __('site.form.note') }}</p>
                </div>

                <form method="post" action="{{ route('leads.store', ['locale' => $locale]) }}" class="rounded-lg border border-line bg-white p-6 text-center shadow-xl shadow-black/5">
                    @csrf

                    @if (session('status'))
                        <div class="mb-4 rounded-lg border border-brand/20 bg-brand-light p-4 text-sm font-bold text-brand-dark">{{ session('status') }}</div>
                    @endif

                    @if ($errors->any())
                        <div class="mb-4 rounded-lg border border-red-200 bg-red-50 p-4 text-sm font-bold text-red-700">{{ __('site.form.errors') }}</div>
                    @endif

                    <label for="name" class="mt-2 block text-sm font-semibold text-ink">{{ __('site.form.fields.name') }}</label>
                    <input id="name" name="name" value="{{ old('name') }}" required class="mt-2 min-h-12 w-full rounded-lg border border-line px-4 text-base outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10">

                    <label for="phone" class="mt-5 block text-sm font-semibold text-ink">{{ __('site.form.fields.phone') }}</label>
                    <input id="phone" name="phone" value="{{ old('phone') }}" class="mt-2 min-h-12 w-full rounded-lg border border-line px-4 text-base outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10">

                    <label for="email" class="mt-5 block text-sm font-semibold text-ink">{{ __('site.form.fields.email') }}</label>
                    <input id="email" type="email" name="email" value="{{ old('email') }}" class="mt-2 min-h-12 w-full rounded-lg border border-line px-4 text-base outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10">

                    <label for="country" class="mt-5 block text-sm font-semibold text-ink">{{ __('site.form.fields.country') }}</label>
                    <input id="country" name="country" value="{{ old('country') }}" class="mt-2 min-h-12 w-full rounded-lg border border-line px-4 text-base outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10">

                    <label for="interest" class="mt-5 block text-sm font-semibold text-ink">{{ __('site.form.fields.interest') }}</label>
                    <select id="interest" name="interest" class="mt-2 min-h-12 w-full rounded-lg border border-line px-4 text-base outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10">
                        <option value="">{{ __('site.form.options.placeholder') }}</option>
                        @foreach (__('site.form.options.items') as $value => $label)
                            <option value="{{ $value }}" @selected(old('interest') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>

                    <label for="message" class="mt-5 block text-sm font-semibold text-ink">{{ __('site.form.fields.message') }}</label>
                    <textarea id="message" name="message" class="mt-2 min-h-28 w-full rounded-lg border border-line px-4 py-3 text-base outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10">{{ old('message') }}</textarea>

                    <label class="mt-5 flex justify-center gap-3 text-center text-sm leading-6 text-muted {{ $isRtl ? 'flex-row-reverse' : '' }}">
                        <input type="checkbox" name="consent" value="1" required class="mt-1 h-5 w-5 shrink-0 rounded border-line text-brand focus:ring-brand">
                        <span>{{ __('site.form.consent') }}</span>
                    </label>

                    <button class="mt-6 inline-flex min-h-12 w-full items-center justify-center rounded-full bg-gradient-to-r from-brand to-brand-dark px-7 text-base font-extrabold text-white shadow-lg shadow-brand/25 transition duration-300 hover:scale-[1.02] hover:from-brand-dark hover:to-brand hover:shadow-xl hover:shadow-brand/30 focus:outline-none focus:ring-4 focus:ring-brand/25" type="submit">
                        {{ __('site.form.submit') }}
                    </button>
                </form>
            </div>
        </section>
    </main>

    <footer class="bg-ink px-5 py-8 text-sm text-white/70 sm:px-8 lg:px-16">
        <div class="mx-auto flex w-full max-w-7xl flex-col items-center gap-3 text-center sm:flex-row sm:justify-center">
            <span>{{ __('site.footer.copy', ['year' => date('Y')]) }}</span>
            <span>{{ __('site.footer.note') }}</span>
        </div>
    </footer>

    <a
        href="https://wa.me/971555574958"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="WhatsApp"
        class="fixed bottom-6 right-6 z-40 flex h-16 w-16 items-center justify-center rounded-full bg-[#1E9447] text-white shadow-2xl shadow-[#1E9447]/30 ring-4 ring-white transition duration-300 hover:scale-105 hover:bg-[#16763A] focus:outline-none focus:ring-4 focus:ring-[#1E9447]/25"
    >
        <svg viewBox="0 0 32 32" class="h-9 w-9" fill="currentColor" aria-hidden="true">
            <path d="M16.04 3C9.04 3 3.34 8.64 3.34 15.57c0 2.3.63 4.54 1.83 6.48L3.25 29l7.13-1.86a12.82 12.82 0 0 0 5.66 1.31c7 0 12.7-5.64 12.7-12.57S23.04 3 16.04 3Zm0 23.31c-1.79 0-3.54-.47-5.07-1.35l-.36-.2-4.23 1.1 1.13-4.06-.24-.42a10.4 10.4 0 0 1-1.58-5.5c0-5.74 4.65-10.43 10.35-10.43s10.35 4.69 10.35 10.43-4.65 10.43-10.35 10.43Zm5.66-7.8c-.31-.15-1.84-.9-2.13-1-.28-.1-.49-.15-.7.15-.2.31-.8 1-.98 1.2-.18.2-.36.23-.67.08-.31-.15-1.31-.48-2.5-1.53a9.38 9.38 0 0 1-1.73-2.15c-.18-.31-.02-.48.14-.63.14-.14.31-.36.46-.54.15-.18.2-.31.31-.51.1-.2.05-.38-.03-.54-.08-.15-.7-1.67-.95-2.28-.25-.6-.51-.52-.7-.53h-.59c-.2 0-.54.08-.82.38-.28.31-1.08 1.05-1.08 2.56s1.1 2.97 1.26 3.18c.15.2 2.17 3.31 5.26 4.64.74.31 1.31.5 1.76.64.74.23 1.41.2 1.94.12.59-.09 1.84-.75 2.1-1.48.26-.72.26-1.34.18-1.48-.08-.13-.28-.2-.59-.36Z"/>
        </svg>
    </a>
</body>
</html>
